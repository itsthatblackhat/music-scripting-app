import { parseScript } from './parser.js';
import { interpretCommands } from './interpreter.js';

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('play-btn').addEventListener('click', async () => {
        await Tone.start();
        console.log("Audio is ready");
        const script = document.getElementById('script-editor').value;
        const tempo = document.getElementById('tempo-input').value;
        playMusic(script, tempo);
    });

    document.getElementById('pause-btn').addEventListener('click', () => {
        Tone.Transport.pause();
    });

    document.getElementById('stop-btn').addEventListener('click', () => {
        Tone.Transport.stop();
        Tone.Transport.cancel();
    });

    document.getElementById('save-config').addEventListener('click', saveConfig);
    document.getElementById('load-config').addEventListener('click', loadConfig);

    initializeKnobs();
});

function playMusic(script, tempo) {
    const commands = parseScript(script);
    Tone.Transport.bpm.value = tempo;
    interpretCommands(commands);
}

function saveConfig() {
    const config = {
        tune: document.getElementById('tune-knob').value,
        glide: document.getElementById('glide-knob').value,
        modulationMix: document.getElementById('modulation-mix-knob').value,
        osc1Waveform: document.getElementById('osc1-waveform').value,
        osc2Waveform: document.getElementById('osc2-waveform').value,
        osc3Waveform: document.getElementById('osc3-waveform').value,
        vol: document.getElementById('vol-knob').value,
        mixOsc1: document.getElementById('mix-osc1-knob').value,
        mixOsc2: document.getElementById('mix-osc2-knob').value,
        mixOsc3: document.getElementById('mix-osc3-knob').value,
        cutoff: document.getElementById('cutoff-knob').value,
        attack: document.getElementById('attack-knob').value,
        decay: document.getElementById('decay-knob').value,
        emphasis: document.getElementById('emphasis-knob').value,
        filterModulation: document.getElementById('filter-modulation').checked,
        amountContour: document.getElementById('amount-contour-knob').value,
        sustain: document.getElementById('sustain-knob').value
    };
    localStorage.setItem('synthConfig', JSON.stringify(config));
    alert('Configuration saved!');
}

function loadConfig() {
    const config = JSON.parse(localStorage.getItem('synthConfig'));
    if (config) {
        document.getElementById('tune-knob').value = config.tune;
        document.getElementById('glide-knob').value = config.glide;
        document.getElementById('modulation-mix-knob').value = config.modulationMix;
        document.getElementById('osc1-waveform').value = config.osc1Waveform;
        document.getElementById('osc2-waveform').value = config.osc2Waveform;
        document.getElementById('osc3-waveform').value = config.osc3Waveform;
        document.getElementById('vol-knob').value = config.vol;
        document.getElementById('mix-osc1-knob').value = config.mixOsc1;
        document.getElementById('mix-osc2-knob').value = config.mixOsc2;
        document.getElementById('mix-osc3-knob').value = config.mixOsc3;
        document.getElementById('cutoff-knob').value = config.cutoff;
        document.getElementById('attack-knob').value = config.attack;
        document.getElementById('decay-knob').value = config.decay;
        document.getElementById('emphasis-knob').value = config.emphasis;
        document.getElementById('filter-modulation').checked = config.filterModulation;
        document.getElementById('amount-contour-knob').value = config.amountContour;
        document.getElementById('sustain-knob').value = config.sustain;
        alert('Configuration loaded!');
    } else {
        alert('No configuration found!');
    }
}

function initializeKnobs() {
    const knobs = [
        { id: 'tune-knob', label: 'Tune', value: 50, min: 0, max: 100 },
        { id: 'glide-knob', label: 'Glide', value: 50, min: 0, max: 100 },
        { id: 'modulation-mix-knob', label: 'Modulation Mix', value: 50, min: 0, max: 100 },
        { id: 'vol-knob', label: 'Volume', value: 50, min: 0, max: 100 },
        { id: 'mix-osc1-knob', label: 'Mix Oscillator 1', value: 50, min: 0, max: 100 },
        { id: 'mix-osc2-knob', label: 'Mix Oscillator 2', value: 50, min: 0, max: 100 },
        { id: 'mix-osc3-knob', label: 'Mix Oscillator 3', value: 50, min: 0, max: 100 },
        { id: 'cutoff-knob', label: 'Cutoff Frequency', value: 50, min: 0, max: 100 },
        { id: 'attack-knob', label: 'Attack Time', value: 50, min: 0, max: 100 },
        { id: 'decay-knob', label: 'Decay Time', value: 50, min: 0, max: 100 },
        { id: 'emphasis-knob', label: 'Emphasis', value: 50, min: 0, max: 100 },
        { id: 'amount-contour-knob', label: 'Amount of Contour', value: 50, min: 0, max: 100 },
        { id: 'sustain-knob', label: 'Sustain Level', value: 50, min: 0, max: 100 },
    ];

    knobs.forEach(knob => {
        const element = document.getElementById(knob.id);
        const newKnob = new Knob({
            label: knob.label,
            value: knob.value,
            min: knob.min,
            max: knob.max,
            width: 100
        });
        element.appendChild(newKnob);
    });
}
